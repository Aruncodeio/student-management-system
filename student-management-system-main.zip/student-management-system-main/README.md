# student-management-system
The Student Management System is a simple yet powerful web-based application designed to manage student records efficiently. It allows to add, update, view, and delete student details such as all details. This project is developed using Python, HTML, and CSS, providing both a functional backend and a clean user interface for easy interaction.
